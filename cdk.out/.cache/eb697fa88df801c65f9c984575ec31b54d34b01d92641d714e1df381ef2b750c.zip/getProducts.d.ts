export declare function main(): Promise<{
    statusCode: number;
    body: string;
    headers: {
        'Content-Type': string;
    };
}>;
